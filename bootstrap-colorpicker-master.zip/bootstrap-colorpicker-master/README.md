# Bootstrap Colorpicker 2.0

[![Build Status](https://travis-ci.org/mjolnic/bootstrap-colorpicker.png)](https://travis-ci.org/mjolnic/bootstrap-colorpicker)

Originally written by [Stefan Petre](http://www.eyecon.ro/)

Read the documentation [here](http://mjolnic.github.io/bootstrap-colorpicker/)

**Check the new  [3.0 version development status](https://github.com/mjolnic/bootstrap-colorpicker/pull/88)**
 
## Contributing

* All the sources are compiled using Grunt, please do not modify dist files directly
* If you modify some source code, please recompile the project dist files
* Check that the index.html demos aren't broken (modify if necessary)
* Test your code at least in Chrome, Firefox and IE >= 10

Thanks =)


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/mjolnic/bootstrap-colorpicker/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

